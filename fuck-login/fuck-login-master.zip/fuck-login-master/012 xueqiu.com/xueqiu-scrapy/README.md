## xueqiu.com fuck-login by scrapy

#### 配置

在 `xueqiu-scrapy/xueqiu/spiders/xq.py` 修改你的用户名和密码

#### 启动
```
cd xueqiu-scrapy/
scrapy crawl xq
```